package Grocery;

//Interface for displaying data of items;

interface Display{
  public void showCost();
  public void showName();
  public void showDescription();
  public void fullDisplay();
}
