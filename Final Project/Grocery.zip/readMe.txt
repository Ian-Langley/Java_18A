Ian Langley
CSE 18A sect 20615

Final Project


This folder contains all contents required to run
the final project for CSE 18A 2021 Winter Quarter.

The intent of this project is to create a program
which allows user to request goods at a date and time.
This design includes the selection of goods, and weekly
delivery in place of month/day specific. 

